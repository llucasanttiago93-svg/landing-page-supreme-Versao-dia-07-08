import {
    useEffect,
    useRef,
    useState,
    type FormEvent,
} from "react";

import "./AIAssistant.css";


/* =====================================================
   CONFIGURAÇÃO
===================================================== */

const API_URL =
    "https://api.vanticompany.com.br/api/ia/chat";


/*
 * Coloque aqui o número oficial do WhatsApp
 * quando formos ativar o atendimento humano.
 *
 * Formato:
 * 5511999999999
 */

const WHATSAPP_NUMBER =
    "";


/* =====================================================
   TIPOS
===================================================== */

type Message = {

    id: number;

    role:
        | "assistant"
        | "user";

    text: string;

};


/* =====================================================
   COMPONENTE
===================================================== */

function AIAssistant() {


    /* =================================================
       ESTADOS
    ================================================= */

    const [
        open,
        setOpen,
    ] = useState(false);


    const [
        message,
        setMessage,
    ] = useState("");


    const [
        messages,
        setMessages,
    ] = useState<Message[]>([

        {
            id: 1,

            role:
                "assistant",

            text:
                "Olá! Como posso te ajudar com o Queridinho Supreme? 😊",

        },

    ]);


    const [
        loading,
        setLoading,
    ] = useState(false);


    const [
        error,
        setError,
    ] = useState(false);


    /* =================================================
       REFERÊNCIAS
    ================================================= */

    const messagesEndRef =
        useRef<HTMLDivElement>(null);


    const inputRef =
        useRef<HTMLInputElement>(null);


    /* =================================================
       ROLAR PARA A ÚLTIMA MENSAGEM
    ================================================= */

    useEffect(() => {

        messagesEndRef.current?.scrollIntoView({

            behavior:
                "smooth",

        });

    }, [
        messages,
        loading,
    ]);


    /* =================================================
       FOCO NO INPUT
    ================================================= */

    useEffect(() => {

        if (
            open &&
            !loading
        ) {

            setTimeout(() => {

                inputRef.current?.focus();

            }, 120);

        }

    }, [
        open,
    ]);


    


    /* =================================================
       ENVIAR MENSAGEM
    ================================================= */

    const sendMessage =
        async (
            event?: FormEvent
        ) => {

            event?.preventDefault();


            const text =
                message.trim();


            if (
                !text ||
                loading
            ) {

                return;

            }


            /* =========================================
               LIMPAR ESTADO
            ========================================= */

            setMessage("");

            setError(false);


            /* =========================================
               ADICIONAR MENSAGEM DO USUÁRIO
            ========================================= */

            const userMessage: Message = {

                id:
                    Date.now(),

                role:
                    "user",

                text,

            };


            const updatedMessages =
                [
                    ...messages,
                    userMessage,
                ];


            setMessages(
                updatedMessages
            );


            setLoading(
                true
            );


            try {

                /* =====================================
                   CHAMADA AO BACKEND
                ===================================== */

                const response =
                    await fetch(
                        API_URL,
                        {

                            method:
                                "POST",

                            headers: {

                                "Content-Type":
                                    "application/json",

                            },

                            body:
                                JSON.stringify({

                                    mensagem:
                                        text,

                                    historico:
                                        updatedMessages
                                            .slice(-12)
                                            .map(
                                                (
                                                    item
                                                ) => ({

                                                    role:
                                                        item.role,

                                                    text:
                                                        item.text,

                                                })
                                            ),

                                }),

                        }
                    );


                /* =====================================
                   VALIDAR RESPOSTA HTTP
                ===================================== */

                if (
                    !response.ok
                ) {

                    throw new Error(
                        "Erro na resposta da API."
                    );

                }


                const data =
                    await response.json();


                if (
                    !data?.resposta
                ) {

                    throw new Error(
                        "Resposta inválida da IA."
                    );

                }


                /* =====================================
                   RESPOSTA DA IA
                ===================================== */

                const assistantMessage: Message = {

                    id:
                        Date.now() + 1,

                    role:
                        "assistant",

                    text:
                        String(
                            data.resposta
                        ),

                };


                setMessages(
                    (
                        currentMessages
                    ) => [

                        ...currentMessages,

                        assistantMessage,

                    ]
                );


            } catch (
                requestError
            ) {

                console.error(
                    "Erro ao conversar com a IA:",
                    requestError
                );


                setError(
                    true
                );


                setMessages(
                    (
                        currentMessages
                    ) => [

                        ...currentMessages,

                        {

                            id:
                                Date.now() + 1,

                            role:
                                "assistant",

                            text:
                                "No momento não consegui responder. Você pode tentar novamente ou falar diretamente com a Vanti pelo WhatsApp.",

                        },

                    ]
                );


            } finally {

                setLoading(
                    false
                );

            }

        };


    /* =================================================
       ENTER
    ================================================= */

    const handleKeyDown =
        (
            event: React.KeyboardEvent<HTMLInputElement>
        ) => {

            if (
                event.key === "Enter"
            ) {

                event.preventDefault();

                sendMessage();

            }

        };


    /* =================================================
       WHATSAPP
    ================================================= */

    const openWhatsApp =
        () => {

            if (
                !WHATSAPP_NUMBER
            ) {

                return;

            }


            const url =
                `https://wa.me/${WHATSAPP_NUMBER}`;


            window.open(
                url,
                "_blank",
                "noopener,noreferrer"
            );

        };


    /* =================================================
       RENDER
    ================================================= */

    return (

        <>

            {/* =================================================
                JANELA DO CHAT
            ================================================= */}

            <div
                className={`
                    ai-chat
                    ${open ? "ai-chat-open" : ""}
                `}
                aria-hidden={!open}
            >

                {/* =============================================
                    CABEÇALHO
                ============================================= */}

                <div className="ai-chat-header">

                    <div className="ai-chat-header-info">

                        <div className="ai-chat-avatar">

                            ✨

                        </div>


                        <div>

                            <strong>
                                Assistente Vanti
                            </strong>

                            <span>

                                <i />

                                Online

                            </span>

                        </div>

                    </div>


                    <button

                        type="button"

                        className="ai-chat-close"

                        onClick={() =>
                            setOpen(false)
                        }

                        aria-label="Fechar assistente"

                    >

                        ×

                    </button>

                </div>


                {/* =============================================
                    MENSAGENS
                ============================================= */}

                <div className="ai-chat-messages">

                    {messages.map(
                        (
                            item
                        ) => (

                            <div
                                key={item.id}
                                className={`
                                    ai-message
                                    ${item.role === "user"
                                        ? "ai-message-user"
                                        : "ai-message-assistant"
                                    }
                                `}
                            >

                                <div className="ai-message-bubble">

                                    {item.text}

                                </div>

                            </div>

                        )
                    )}


                    {/* =========================================
                        LOADING
                    ========================================= */}

                    {loading && (

                        <div className="ai-message ai-message-assistant">

                            <div className="ai-message-bubble ai-loading">

                                <span />
                                <span />
                                <span />

                            </div>

                        </div>

                    )}


                    <div
                        ref={
                            messagesEndRef
                        }
                    />

                </div>


                {/* =============================================
                    ERRO
                ============================================= */}

                {error && WHATSAPP_NUMBER && (

                    <button

                        type="button"

                        className="ai-whatsapp-button"

                        onClick={
                            openWhatsApp
                        }

                    >

                        💬 Falar com a Vanti

                    </button>

                )}


                {/* =============================================
                    INPUT
                ============================================= */}

                <form
                    className="ai-chat-form"
                    onSubmit={
                        sendMessage
                    }
                >

                    <input

                        ref={
                            inputRef
                        }

                        type="text"

                        value={
                            message
                        }

                        onChange={(
                            event
                        ) =>
                            setMessage(
                                event.target.value
                            )
                        }

                        onKeyDown={
                            handleKeyDown
                        }

                        placeholder="Digite sua dúvida..."

                        autoComplete="off"

                        disabled={
                            loading
                        }

                    />


                    <button

                        type="submit"

                        className="ai-send-button"

                        disabled={
                            !message.trim() ||
                            loading
                        }

                        aria-label="Enviar mensagem"

                    >

                        ↑

                    </button>

                </form>

            </div>


            {/* =================================================
                BOTÃO FLUTUANTE
            ================================================= */}

            <button

                type="button"

                className={`
                    ai-floating-button
                    ${open ? "ai-floating-button-open" : ""}
                `}

                onClick={() =>
                    setOpen(
                        (
                            current
                        ) => !current
                    )
                }

                aria-label={
                    open
                        ? "Fechar assistente"
                        : "Abrir assistente"
                }

                aria-expanded={
                    open
                }

            >

                {open
                    ? "×"
                    : "✦"
                }

            </button>

        </>

    );

}


export default AIAssistant;