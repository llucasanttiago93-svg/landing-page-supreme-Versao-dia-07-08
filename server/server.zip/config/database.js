import mysql from "mysql2/promise";


/* =====================================================
   CONEXÃO COM MYSQL
===================================================== */

const pool = mysql.createPool({

  host:
    process.env.DB_HOST,

  port:
    Number(process.env.DB_PORT) || 3306,

  user:
    process.env.DB_USER,

  password:
    process.env.DB_PASSWORD,

  database:
    process.env.DB_NAME,

  waitForConnections:
    true,

  connectionLimit:
    10,

  queueLimit:
    0,

});


/* =====================================================
   TESTAR CONEXÃO
===================================================== */

export async function testarBanco() {

  let connection;

  try {

    connection =
      await pool.getConnection();

    console.log(
      "================================="
    );

    console.log(
      "MYSQL CONECTADO COM SUCESSO"
    );

    console.log(
      "Banco:",
      process.env.DB_NAME
    );

    console.log(
      "================================="
    );


  } finally {

    if (connection) {

      connection.release();

    }

  }

}


/* =====================================================
   EXPORTAR POOL
===================================================== */

export default pool;